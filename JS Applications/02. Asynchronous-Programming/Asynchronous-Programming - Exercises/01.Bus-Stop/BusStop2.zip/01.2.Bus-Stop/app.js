async function getInfo() {
    let input = document.getElementById('stopId').value;
    let stopName = document.getElementById('stopName');
    let ul = document.getElementById('buses');

        fetch(`http://localhost:3030/jsonstore/bus/businfo/${input}`)
        .then((response) => response.json())
        .then((data) => {
            let name = data.name;
            let busses = data.buses;

        stopName.textContent = name
        ul.innerHTML = '';
        Object.keys(busses).forEach((bus) => {
            let li = document.createElement('li');
            li.textContent = `Bus ${bus} arrives in ${busses[bus]} minutes`;
            ul.appendChild(li);
        })
    })
    .catch((error) => {
        ul.innerHTML = '';
        stopName.textContent = 'Error'
    })



}